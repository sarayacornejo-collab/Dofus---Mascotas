# tendencias-prl

Recolector de tendencias del nicho de **Prevención de Riesgos Laborales (PRL/SST)** en LATAM y España, integrado como **skill de Claude Code**.

> ✨ **No requiere API key de Anthropic.** La inferencia (síntesis editorial, propuestas de Reels, líneas editoriales) la hace **Claude Code consumiendo tu plan Pro/Max**. El script Python solo recolecta datos.

## Qué hace

1. **Script Python** (`scripts/collect.py`) recolecta tendencias de tres fuentes:
   - Google Trends (vía pytrends, sin API key)
   - YouTube Data API v3 (opcional)
   - TikTok Creative Center (scraping público best-effort)
2. Empaqueta todo en un markdown con contexto del nicho.
3. **Skill de Claude Code** (`.claude/skills/tendencias-prl/SKILL.md`) lee ese markdown y genera:
   - Lectura semanal de tendencias.
   - **3 propuestas concretas** de Reel/TikTok con hook, estructura por segundos, audio, hashtags, CTA, riesgo editorial.
   - **3 secciones genéricas** para sostener una línea editorial coherente y rotable.

## Setup

```bash
git clone <este-repo>  # o partí del directorio local ya creado
cd tendencias-prl
python3 -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt
cp .env.example .env
```

Editá `.env` y opcionalmente añadí `YOUTUBE_API_KEY` (Google Cloud Console → APIs & Services → Credentials). Sin esa key, el script salta YouTube y trabaja solo con Trends + TikTok.

## Uso desde Claude Code (recomendado)

Abrí Claude Code en el directorio del proyecto:

```bash
cd /home/user/tendencias-prl
claude
```

Y pedí:

> *"generá el informe semanal de tendencias PRL"*

Claude Code detecta la skill `tendencias-prl` por su descripción, ejecuta el script, lee los datos y produce el informe. Todo el costo de inferencia sale de tu plan Pro/Max — cero API extra.

También podés invocarla explícitamente:

```
/tendencias-prl
```

## Uso del script standalone (sin Claude)

Si querés solo los datos crudos para pegarlos en otra parte:

```bash
# imprime markdown a stdout
python scripts/collect.py

# o guarda en archivo
python scripts/collect.py --output reports/$(date +%Y-%m-%d).md

# regiones y ventana custom
python scripts/collect.py --regions ES,MX --timeframe "today 1-m"

# saltar fuentes
python scripts/collect.py --skip-tiktok --skip-youtube
```

Después podés copiar ese markdown a claude.ai y pedir el informe ahí (también consumiendo tu plan Pro).

## Flags del script

| Flag | Default | Descripción |
|---|---|---|
| `--regions` | `ES,MX,AR,CO,CL,PE` | Códigos ISO país, CSV. |
| `--timeframe` | `now 7-d` | Ventana Trends (`now 1-d`, `now 7-d`, `today 1-m`, `today 3-m`). |
| `--keywords` | 15 semilla PRL | Override de keywords (CSV). |
| `--skip-trends` / `--skip-youtube` / `--skip-tiktok` | off | Salta esa fuente. |
| `--output` | (stdout) | Ruta donde escribir el markdown. |

## Estructura del proyecto

```
tendencias-prl/
├── .claude/
│   └── skills/
│       └── tendencias-prl/
│           └── SKILL.md          ← rol + workflow para Claude Code
├── scripts/
│   ├── collect.py                ← entry point del recolector
│   ├── config.py                 ← keywords semilla + regiones
│   └── sources/
│       ├── google_trends.py      ← pytrends
│       ├── youtube.py            ← YouTube Data API v3
│       └── tiktok_creative.py    ← TikTok Creative Center
├── requirements.txt
├── .env.example
├── .gitignore
└── README.md
```

## Adaptarlo a otro nicho

1. Editá `NICHE` y `SEED_KEYWORDS` en `scripts/config.py`.
2. Reescribí `.claude/skills/tendencias-prl/SKILL.md` con el rol nuevo y el marco normativo/contextual del nuevo nicho.
3. Renombrá la carpeta de la skill a algo descriptivo del nuevo nicho.

## Limitaciones conocidas

- **TikTok Creative Center** no tiene API oficial. El endpoint `creative_radar_api` se usa best-effort y puede romperse o estar geo-bloqueado. El script lo declara y sigue.
- **pytrends** puede recibir 429 si abusás; esperá 5-10 min entre corridas pesadas.
- **YouTube Data API** tiene cuota gratuita de 10 000 unidades/día (≈100 búsquedas con stats).
- Los hashtags de TikTok que devolvemos son **trending generales por país**, no PRL-específicos. Claude los usa solo como pista de formatos virales para colonizar con ángulo PRL.
