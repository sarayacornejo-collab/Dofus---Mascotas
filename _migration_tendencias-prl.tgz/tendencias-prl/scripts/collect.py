"""Recolector de tendencias PRL/SST → markdown listo para Claude Code.

Este script NO llama a Anthropic. Solo recolecta datos de Google Trends,
YouTube Data API y TikTok Creative Center, y los empaqueta en un markdown
que la skill `tendencias-prl` consume desde Claude Code (o que vos podés
pegar en claude.ai).

Uso:
    python scripts/collect.py                              # imprime a stdout
    python scripts/collect.py --output /tmp/trends.md      # escribe a archivo
    python scripts/collect.py --regions ES,MX --skip-tiktok
"""
from __future__ import annotations

import argparse
import sys
from datetime import date
from pathlib import Path

# Permite ejecutar desde la raíz del proyecto: `python scripts/collect.py`
sys.path.insert(0, str(Path(__file__).parent))

try:
    from dotenv import load_dotenv

    load_dotenv(Path(__file__).parent.parent / ".env")
except ImportError:
    pass

from config import NICHE, REGION_LABELS, SEED_KEYWORDS, Settings
from sources import google_trends, tiktok_creative, youtube


def _parse_args() -> argparse.Namespace:
    p = argparse.ArgumentParser(
        description="Recolector de tendencias PRL/SST → markdown para Claude Code"
    )
    p.add_argument("--regions", help="Lista CSV de códigos ISO país (ej: ES,MX,AR)")
    p.add_argument("--timeframe", help="Ventana Google Trends (ej: now 7-d, today 1-m)")
    p.add_argument("--keywords", help="Lista CSV de keywords semilla")
    p.add_argument("--skip-trends", action="store_true")
    p.add_argument("--skip-youtube", action="store_true")
    p.add_argument("--skip-tiktok", action="store_true")
    p.add_argument(
        "--output",
        help="Ruta donde escribir el markdown. Si se omite, imprime a stdout.",
    )
    return p.parse_args()


def main() -> int:
    args = _parse_args()
    settings = Settings()
    if args.regions:
        settings.regions = [r.strip().upper() for r in args.regions.split(",") if r.strip()]
    if args.timeframe:
        settings.timeframe = args.timeframe

    keywords = SEED_KEYWORDS
    if args.keywords:
        keywords = [k.strip() for k in args.keywords.split(",") if k.strip()]

    for problem in settings.validate():
        print(f"⚠️  {problem}", file=sys.stderr)

    print(f"▶ Regiones: {settings.regions}", file=sys.stderr)
    print(f"▶ Keywords: {len(keywords)} semillas", file=sys.stderr)
    print(f"▶ Timeframe Trends: {settings.timeframe}", file=sys.stderr)
    print(file=sys.stderr)

    # 1. Google Trends
    if args.skip_trends:
        trends_md = "_(Saltado por --skip-trends.)_"
    else:
        print("⏳ Consultando Google Trends…", file=sys.stderr)
        rows = google_trends.fetch_trends(keywords, settings.regions, settings.timeframe)
        trends_md = google_trends.to_markdown(rows)
        print(f"   → {len(rows)} filas recuperadas", file=sys.stderr)

    # 2. YouTube
    if args.skip_youtube or not settings.youtube_api_key:
        if not settings.youtube_api_key and not args.skip_youtube:
            print("⏭  YouTube: YOUTUBE_API_KEY no definida, saltando.", file=sys.stderr)
        youtube_md = "_(Saltado o sin YOUTUBE_API_KEY.)_"
    else:
        print("⏳ Consultando YouTube Data API…", file=sys.stderr)
        videos = youtube.fetch_youtube(settings.youtube_api_key, keywords, settings.regions)
        youtube_md = youtube.to_markdown(videos)
        print(f"   → {len(videos)} videos recuperados", file=sys.stderr)

    # 3. TikTok Creative Center
    if args.skip_tiktok:
        tiktok_md = "_(Saltado por --skip-tiktok.)_"
    else:
        print("⏳ Consultando TikTok Creative Center…", file=sys.stderr)
        hashtags = tiktok_creative.fetch_trending_hashtags(settings.regions)
        tiktok_md = tiktok_creative.to_markdown(hashtags)
        print(f"   → {len(hashtags)} hashtags recuperados", file=sys.stderr)

    output = _build_output(settings, keywords, trends_md, youtube_md, tiktok_md)

    if args.output:
        out_path = Path(args.output)
        out_path.parent.mkdir(parents=True, exist_ok=True)
        out_path.write_text(output, encoding="utf-8")
        print(f"\n✅ Datos escritos en {out_path}", file=sys.stderr)
    else:
        sys.stdout.write(output)

    return 0


def _build_output(
    settings: Settings,
    keywords: list[str],
    trends_md: str,
    youtube_md: str,
    tiktok_md: str,
) -> str:
    regions_human = ", ".join(f"{r} ({REGION_LABELS.get(r, '?')})" for r in settings.regions)
    return f"""# Tendencias recolectadas — {date.today().isoformat()}

**Nicho:** {NICHE}
**Regiones:** {regions_human}
**Ventana Trends:** `{settings.timeframe}`
**Keywords semilla:** {len(keywords)}

---

## Google Trends
{trends_md}

## YouTube — videos PRL recientes
{youtube_md}

## TikTok Creative Center — hashtags trending generales
{tiktok_md}
"""


if __name__ == "__main__":
    raise SystemExit(main())
